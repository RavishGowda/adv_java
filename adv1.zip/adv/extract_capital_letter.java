

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/extract_capital_letter")
public class extract_capital_letter extends HttpServlet {
	
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the Name");
		String name= sc.next();
		initials(name,pw);
		
		
	}

	private void initials(String name, PrintWriter pw) {
		// TODO Auto-generated method stub
		for(int i = 0; i < name.length(); i++) {
	         if(Character.isUpperCase(name.charAt(i))) {
	             pw.print(name.charAt(i));
	}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
